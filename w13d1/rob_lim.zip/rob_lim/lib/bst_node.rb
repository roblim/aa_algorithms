class BSTNode
  attr_accessor :parent, :left, :right, :value

  def initialize(value)
    @value = value
    @parent
    @left
    @right
  end
end

require_relative 'graph'
require 'byebug'
# Implementing topological sort using both Khan's and Tarian's algorithms

def topological_sort(vertices)
  in_edge_counts = {}
  queue = []

  vertices.each do |v|
    in_edge_counts[v] = v.in_edges.count
    queue << v if v.in_edges.empty?
  end

  sorted_vertices = []

  until queue.empty?
    vertex = queue.shift
    sorted_vertices << vertex
    vertices.delete(vertex)
    vertex.out_edges.each do |e|
      to_vertex = e.to_vertex

      in_edge_counts[to_vertex] -= 1
      queue << to_vertex if in_edge_counts[to_vertex] == 0
    end
  end

  vertices.empty? ? sorted_vertices : []
end

# def topological_sort(vertices)
#   result = []
#   visited = {}
#
#   until vertices.empty?
#     vertices.each do |vertex|
#       terminus = traverse(vertex, visited)
#       result.unshift(terminus)
#       visited[terminus] = true
#       vertices.delete(terminus)
#     end
#   end
#   result
# end
#
# def traverse(vertex, visited)
#   return vertex if visited[vertex].nil? && vertex.out_edges.empty?
#   vertex.out_edges.each do |out_edge|
#     traverse(out_edge.to_vertex, visited)
#   end
# end
